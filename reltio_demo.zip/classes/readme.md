Demo 

Reltio UI:

https://pilot.reltio.com/ui/E03e9u0V9lOy0Kp/login.html
user: mulesoft.demo
password: MuleSoft!

For the bulkfile flow see "MuleSoft merge and delete.pptx" in src/main.resources on how to merge 
and delete products prior to running the flow so that the inserts appear as new records.

For the reltio flow use the search box to find the entity with ID: dGlLY05 and do refreshes to 
show the tile being updated

bulkfile flow:
Discuss MDM typically uses ETL and MuleSoft addresses this pattern. 
show ETL load of products using the bulkfile flow. 
Show the dashboard through the Reltio UI - the products appear as a graph.
To run the demo clean up the products through the Reltio UI (above) then drop the products.csv
into the DemoBulkCsvIn directory under src/test/resources
Update the Reltio UI and show the products have been created

reltio flow:

The power of Mule is API led architecture - the ability to wrap systems (Reltio) into an API 
that exposes all teh data, but then at the process and experience level the ability to orchestrate,
filter and adapt APIs to business processes and user UIs.

Show Retio flow - demonstrate the Reltio connector as an example of a Sstem API.
The value of teh connector is that it  abstracts the Reltio REST/JSON interface and schema 
into a higher level interface (objects and functions).
Demonstrate Datasense on teh output and discuss the Reltio object schema - it's complex and long
As an example show src/test/resources/sample_data/list_list_json_1.json 
 
API Led example as a simple proof - we want to create a simple API to manipulate a contact
and will use just 3 fields - first name, last name and title.
We will query (GET) a contact by UID
We will update a contact's title (POST) by UID with a new title.

Demonstrate Data Sense and DataWeave, and the APIkit console.

Run the demo. 

Show the contact in the Reltio UI being updated.